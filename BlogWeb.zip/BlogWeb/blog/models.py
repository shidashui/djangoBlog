from django.db import models
import markdown
from django.utils.html import strip_tags

# Create your models here.
from django.contrib.auth.models import User
from django.urls import reverse

#文章分类模型
class Category(models.Model):
    name = models.CharField(max_length=100)

    def __str__(self):
        return self.name

#文章标签模型
class Tag(models.Model):
    name = models.CharField(max_length=100)

    def __str__(self):
        return self.name

#文章模型
class Post(models.Model):
    title = models.CharField(max_length=70)
    body = models.TextField()
    created_time = models.DateTimeField()
    modified_time = models.DateTimeField()
    excerpt = models.CharField(max_length=200, blank=True) #摘要
    category = models.ForeignKey(Category, on_delete=models.CASCADE)
    tags = models.ManyToManyField(Tag, blank=True)
    author = models.ForeignKey(User, on_delete=models.CASCADE)
    #新字段（增加新字段要设置默认值）
    views = models.PositiveIntegerField(default=0)

    def __str__(self):
        return self.title

    def get_absolute_url(self):
        return reverse('blog:detail', kwargs={'pk': self.pk})

    class Meta:
        ordering = ['-created_time']

    #阅读量+1
    def increase_views(self):
        self.views += 1
        self.save(update_fields=['views'])

    #摘要  复写save（）方法
    #有个小问题，如果body字段数据更新，但是摘要不更新，可以考虑进行修改。###################################################
    def save(self, *args, **kwargs):
        if not self.excerpt:
            md = markdown.Markdown(extensions=[
                'markdown.extensions.extra',
                'markdown.extensions.codehilite',
            ])
            #先将markdown文本渲染成HTML文本，再去掉全部html标签，再取54个字符
            self.excerpt = strip_tags(md.convert(self.body))[:54]
        super(Post, self).save(*args, **kwargs)